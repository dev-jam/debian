"""
Minimal Python-expression -> JavaScript-expression converter.

Intended for small inline expressions (e.g. conditions/feedback text) that need
to be embedded directly in JS template literals -- NOT a general Python-to-JS
transpiler. Always produces a single JS expression, never statements or helper
functions.

Supports: comparisons (==, !=, <, <=, >, >=, in, not in, is, is not),
boolean ops (and/or/not), arithmetic (+ - * / % ** //), ternary (a if b else c),
attribute access, subscripting, function calls, lists/tuples, dicts,
constants (True/False/None/str/num).

Extend the BINOP / UNARYOP / CMPOP tables or add branches to `_convert` as
needed -- the Python `ast` grammar for expressions is small and very stable,
so this is easy to maintain across Python versions.
"""

import ast
import json

BINOP = {
    ast.Add: '+', ast.Sub: '-', ast.Mult: '*', ast.Div: '/',
    ast.Mod: '%', ast.Pow: '**',
}
UNARYOP = {
    ast.Not: '!', ast.USub: '-', ast.UAdd: '+',
}
CMPOP = {
    ast.Eq: '===', ast.NotEq: '!==',
    ast.Lt: '<', ast.LtE: '<=', ast.Gt: '>', ast.GtE: '>=',
    ast.Is: '===', ast.IsNot: '!==',
}


def py2js(expr: str) -> str:
    """Convert a Python expression (as a string) to a JavaScript expression
    (as a string).
    """
    tree = ast.parse(expr.strip(), mode="eval").body
    return _convert(tree)


def _convert(node):
    if isinstance(node, ast.BoolOp):
        op = ' && ' if isinstance(node.op, ast.And) else ' || '
        return '(' + op.join(_convert(v) for v in node.values) + ')'

    if isinstance(node, ast.BinOp):
        if isinstance(node.op, ast.FloorDiv):
            return f'Math.floor({_convert(node.left)} / {_convert(node.right)})'
        op = BINOP.get(type(node.op))
        if op is None:
            raise NotImplementedError(f'Unsupported binary operator: {node.op}')
        return f'({_convert(node.left)} {op} {_convert(node.right)})'

    if isinstance(node, ast.UnaryOp):
        op = UNARYOP.get(type(node.op))
        if op is None:
            raise NotImplementedError(f'Unsupported unary operator: {node.op}')
        operand = _convert(node.operand)
        # Python's `not` has lower precedence than comparisons, but JS's `!`
        # has higher precedence than `===`/`!==`. Wrap comparisons in parens
        # to preserve the intended semantics (e.g. `not (a == b)` -> `!(a === b)`).
        if isinstance(node.op, ast.Not) and isinstance(node.operand, ast.Compare):
            return f'!({operand})'
        return f'{op}{operand}'

    if isinstance(node, ast.Compare):
        parts = []
        left = node.left
        for op, right in zip(node.ops, node.comparators):
            if isinstance(op, (ast.In, ast.NotIn)):
                neg = '!' if isinstance(op, ast.NotIn) else ''
                parts.append(f'{neg}({_convert(right)}.includes({_convert(left)}))')
            else:
                cmp = CMPOP.get(type(op))
                if cmp is None:
                    raise NotImplementedError(f'Unsupported comparison operator: {op}')
                parts.append(f'{_convert(left)} {cmp} {_convert(right)}')
            left = right
        return '(' + ' && '.join(parts) + ')' if len(parts) > 1 else parts[0]

    if isinstance(node, ast.IfExp):
        return f'({_convert(node.test)} ? {_convert(node.body)} : {_convert(node.orelse)})'

    if isinstance(node, ast.Constant):
        v = node.value
        if v is True:
            return 'true'
        if v is False:
            return 'false'
        if v is None:
            return 'null'
        if isinstance(v, str):
            return json.dumps(v)
        return repr(v)

    if isinstance(node, ast.Name):
        return node.id

    if isinstance(node, ast.Attribute):
        return f'{_convert(node.value)}.{node.attr}'

    if isinstance(node, ast.Subscript):
        return f'{_convert(node.value)}[{_convert(node.slice)}]'

    if isinstance(node, ast.Call):
        func = _convert(node.func)
        args = ', '.join(_convert(a) for a in node.args)
        return f'{func}({args})'

    if isinstance(node, (ast.List, ast.Tuple)):
        return '[' + ', '.join(_convert(e) for e in node.elts) + ']'

    if isinstance(node, ast.Dict):
        pairs = ', '.join(f'{_convert(k)}: {_convert(v)}' for k, v in zip(node.keys, node.values))
        return '{' + pairs + '}'

    raise NotImplementedError(f'Unsupported node: {type(node).__name__}')
