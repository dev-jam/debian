"""Extension to integrate OSWeb into OpenSesame"""

__version__ = '2.2.9.4'
# The name of the package to check for updates on conda and pip
packages = ['opensesame-extension-osweb']
