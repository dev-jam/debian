#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Part of the PsychoPy library
# Copyright (C) 2002-2018 Jonathan Peirce (C) 2019-2025 Open Science Tools Ltd.
# Distributed under the terms of the GNU General Public License (GPL).

"""Base class for serial devices. Includes some convenience methods to open
ports and check for the expected device
"""

import sys
import time

from psychopy import logging
import serial

from psychopy.localization import _translate
from .exceptions import DeviceNotConnectedError
from psychopy.tools import systemtools as st
from psychopy.tools.attributetools import AttributeGetSetMixin
from .base import BaseDevice
from psychopy.hardware import DeviceManager
from psychopy.constants import NOT_STARTED


def _findPossiblePorts():
    if sys.platform == 'win32':
        # get profiles for all serial port devices
        profiles = st.systemProfilerWindowsOS(classname="Ports")
        # get COM port for each device
        final = []
        for profile in profiles:
            # find "COM" in profile description
            desc = profile['Device Description']
            start = desc.find("COM") + 3
            end = desc.find(")", start)
            # skip this profile if there's no reference to a COM port
            if -1 in (start, end):
                continue
            # get COM port number
            num = desc[start:end]
            # skip this profile if COM port number doesn't look numeric
            if not num.isnumeric():
                continue
            # store COM port
            final.append(f"COM{num}")
    else:
        # on linux and mac the options are too wide so use serial.tools
        from serial.tools import list_ports
        poss = list_ports.comports()
        # filter out any that report 'n/a' for their hardware
        final = []
        for p in poss:
            if p[2] != 'n/a':
                final.append(p[0])  # just the port address
    return final


# map out all ports on this device, to be filled as serial devices are initialised
ports = {port: None for port in _findPossiblePorts()}


class SerialOut(AttributeGetSetMixin):
    """
    Wrapper around SerialDevice which handles Builder specific stuff (e.g. started/active/stopped 
    status) on a per-Component basis
    """

    def __init__(self, device, autolog=True):
        if isinstance(device, SerialDevice):
            # if given a serial device
            self.device = device
        # if given a string, get via DeviceManager
        if isinstance(device, str):
            if device in DeviceManager.devices:
                self.device = DeviceManager.getDevice(device)
            else:
                # don't use formatted string literals in _translate()
                raise ValueError(_translate(
                    "Could not find device named '{device}', make sure it has been set up "
                    "in DeviceManager."
                ).format(device))
        # set an initial status
        self.status = NOT_STARTED
        # set autolog
        self.autolog = autolog
    
    def __getattr__(self, name):
        try:
            # try as normal first
            return getattr(self, name)
        except AttributeError as err:
            if hasattr(self.device, name):
                # if this instance doesn't have the attribute but the device does, warn and use that
                logging.warn(
                    f"SerialOut has no attribute {name}, but SerialDevice does, so using "
                    f"SerialDevice.{name}. To silence this message, use `.device.{name}` instead."
                )
                return getattr(self.device, name)
            else:
                # if it just doesn't have the attribute, fail as normal
                raise err
    
    @property
    def com(self):
        return self.device.com
    
    @property
    def portString(self):
        return self.device.portString

    def pause(self):
        """Pause for a default period for this device
        """
        self.device.pause()
    
    def sendMessage(self, message, autoLog=True):
        return self.device.sendMessage(
            message, 
            autoLog=autoLog
        )
    
    def getResponse(self, length=1, timeout=0.1, autoLog=True):
        return self.device.getResponse(
            length=length, 
            timeout=timeout, 
            autoLog=autoLog
        )

    def awaitResponse(self, multiline=False, timeout=None):
        return self.device.awaitResponse(
            self,
            multiline=multiline,
            timeout=timeout
        )

    def isAwake(self):
        return self.device.isAwake()
    
    def isOpen(self):
        return self.device.isOpen()


class SerialDevice(BaseDevice, AttributeGetSetMixin):
    """A base class for serial devices, to be sub-classed by specific devices

    If port=None then the SerialDevice.__init__() will search for the device
    on known serial ports on the computer and test whether it has found the
    device using isAwake() (which the sub-classes need to implement).
    """
    name = b'baseSerialClass'
    longName = ""
    # list of supported devices (if more than one supports same protocol)
    driverFor = []

    def __new__(cls, *args, **kwargs):
        import inspect
        # convert args to kwargs
        argNames = inspect.getfullargspec(cls.__init__).args
        for i, arg in enumerate(args):
            kwargs[argNames[i]] = arg
        # iterate through existing devices
        for other in ports.values():
            # skip None
            if other is None:
                continue
            # if device already represented, use existing object
            if other.isSameDevice(kwargs):
                return other

        # if first object to represent this device, make as normal
        return super(BaseDevice, cls).__new__(cls)

    def __init__(self, port=None, baudrate=9600,
                 byteSize=8, stopBits=1,
                 parity="N",  # 'N'one, 'E'ven, 'O'dd, 'M'ask,
                 eol=b"\n",
                 maxAttempts=1, pauseDuration=0.1,
                 checkAwake=True):

        if not serial:
            raise ImportError('The module serial is needed to connect to this'
                              ' device. On most systems this can be installed'
                              ' with\n\t easy_install pyserial')

        # get a list of port names to try
        if port is None:
            tryPorts = self._findPossiblePorts()
        elif type(port) in [int, float]:
            tryPorts = ['COM%i' % port]
        else:
            tryPorts = [port]

        self.pauseDuration = pauseDuration
        self.com = None
        self.OK = False
        self.maxAttempts = maxAttempts
        self.eol = eol
        self.type = self.name  # for backwards compatibility

        # try to open the port
        for portString in tryPorts:
            try:
                self.com = serial.Serial(
                    portString,
                    baudrate=baudrate, bytesize=byteSize,    # number of data bits
                    parity=parity,    # enable parity checking
                    stopbits=stopBits,  # number of stop bits
                    timeout=self.pauseDuration * 3,             # set a timeout value, None for
                    # waiting forever
                    xonxoff=0,             # enable software flow control
                    rtscts=0,)              # enable RTS/CTS flow control

                self.portString = portString
            except Exception:
                if port:
                    # the user asked for this port and we couldn't connect
                    logging.warn("Couldn't connect to port %s" % portString)
                else:  # we were trying this port on a guess
                    msg = "Tried and failed to connect to port %s"
                    logging.debug(msg % portString)
                continue  # try the next port

            if not self.com.isOpen():
                try:
                    self.com.open()
                except Exception:
                    msg = ("Couldn't open port %s. Is it being used by "
                           "another program?")
                    logging.info(msg % self.portString)
                    continue

            if checkAwake and self.com.isOpen():
                # we have an open com port. try to send a command
                self.com.flushInput()
                awake = False  # until we confirm otherwise
                for repN in range(self.maxAttempts):
                    awake = self.isAwake()
                    if awake:
                        msg = "Opened port %s and looks like a %s"
                        logging.info(msg % (self.portString, self.name))
                        self.OK = True
                        self.pause()
                        break
                if not awake:
                    msg = "Opened port %s but it didn't respond like a %s"
                    logging.info(msg % (self.portString, self.name))
                    self.com.close()
                    self.OK = False
                else:
                    break

        if self.OK:  # we have successfully sent and read a command
            msg = "Successfully opened %s with a %s"
            logging.info(msg % (self.portString, self.name))
            # store device in ports dict
            global ports
            ports[port] = self
        else:
            raise DeviceNotConnectedError(
                _translate(
                    "Failed to connect to device on {port}, this device is likely to have "
                    "been disconnected, or the port is in use by another application."
                ).format(port=port), 
                deviceClass=SerialDevice
            )
        # we aren't in a time-critical period so flush messages
        logging.flush()
    
    @property
    def eol(self):
        return self._eol

    @eol.setter
    def eol(self, value):
        # coerce to bytes
        if type(value) is not bytes:
            value = bytes(value, "utf-8")
        # set
        self._eol = value

    def isAwake(self):
        """This should be overridden by the device class
        """
        # send a command to the device and check the response matches what
        # you expect; then return True or False
        return True

    def pause(self):
        """Pause for a default period for this device
        """
        time.sleep(self.pauseDuration)

    def sendMessage(self, message, autoLog=True):
        """
        Send a command to the device (does not wait for a reply or sleep())

        Parameters
        ----------
        message : str or bytes
            Message to send to the device - if given as a string, SerialDevice will encode it 
            into bytes for you
        autoLog : bool
            If True, then the message sent will be logged at level DEBUG
        """
        if self.com.inWaiting():
            inStr = self.com.read(self.com.inWaiting())
            msg = "Sending '%s' to %s but found '%s' on the input buffer"
            logging.warning(msg % (message, self.name, inStr))
        # transform string input into bytes
        if isinstance(message, str):
            message = bytes(message, 'utf-8')
        # transform integers into bytes via bytearray
        if isinstance(message, int):
            message = bytes(bytearray([message]))
        # transform arrays into bytearray
        if isinstance(message, (list, tuple)):
            message = bytearray(message)
        if not message.endswith(self.eol):
            message += self.eol  # append a newline if necess
        self.com.write(message)
        self.com.flush()
        # log
        if autoLog:
            logging.debug(
                f"Sent {self.name} message: " + repr(message)
            )
            # sending isn't as time-critical as receiving, so we can flush now
            logging.flush()

    def getResponse(self, length=1, timeout=0.1, autoLog=True):
        """
        Read the latest response from the serial port

        Parameters
        ----------
        length : int
           One of:
           - 1: a single-line reply (use readline())
           - 2: a multiline reply (use readlines() which *requires* timeout)
           - -1: may not be any EOL character; just read whatever chars are there
        timeout : float
            How long to wait for a response before giving up
        autoLog : bool
            If True, then the message sent will be logged at level DEBUG
        """
        # get reply (within timeout limit)
        self.com.timeout = timeout
        if length == 1:
            retVal = self.com.readline()
        elif length > 1:
            retVal = self.com.readlines()
            retVal = [line.decode('utf-8') for line in retVal]
        else:  # was -1?
            retVal = self.com.read(self.com.inWaiting())
        if type(retVal) is bytes:
            retVal = retVal.decode('utf-8')
        # log
        if retVal and autoLog:
            logging.debug(f"Received {self.name} message: " + repr(retVal))
        
        return retVal

    def awaitResponse(self, multiline=False, timeout=None):
        """
        Repeatedly request responses until one arrives, or until a timeout is hit.

        Parameters
        ----------
        multiline : bool
            Look for additional lines after the first? WARNING: May be slow if there are none.
        timeout
            Time after which to give up waiting (by default is 10x pause length)

        Returns
        -------
        str
            The message eventually received
        """
        # default timeout
        if timeout is None:
            timeout = 1
        # set timeout
        self.com.timeout = self.pauseDuration
        # get start time
        start = time.time()
        t = time.time() - start
        # get responses until we have one
        resp = b""
        while not resp and t < timeout:
            t = time.time() - start
            resp = self.com.read()
        # get remaining chars
        active = True
        while active and t < timeout:
            # get resp
            thisResp = self.com.read_until(self.eol)
            # concatenate it to what we already have
            resp += thisResp
            # decide whether to continue
            if thisResp.endswith(self.eol) and not multiline:
                # in single line mode, always stop after an eol
                active = False
            else:
                # otherwise, continue so long as we have a response
                active = len(thisResp)
            # wait for more
            self.pause()
        # if we timed out, return None
        if t > timeout:
            return
        # decode to str
        resp = resp.decode('utf-8')
        # if multiline, split by eol
        if multiline:
            resp = resp.split(self.eol.decode("utf-8"))

        return resp

    def isSameDevice(self, other):
        """
        Determine whether this object represents the same physical device as a given other object.

        Parameters
        ----------
        other : SerialDevice, dict
            Other SerialDevice to compare against, or a dict of params (which must include
            `port` as a key)

        Returns
        -------
        bool
            True if the two objects represent the same physical device
        """
        if isinstance(other, SerialDevice):
            # if given another object, get port
            portString = other.portString
        elif isinstance(other, dict) and "port" in other:
            # if given a dict, get port from key
            portString = other['port']
            # make sure port is in the correct format
            if not other['port'].startswith("COM"):
                portString = "COM" + other['port']
        else:
            # if the other object is the wrong type or doesn't have a port, it's not this
            return False

        return self.portString == portString

    @staticmethod
    def getAvailableDevices():
        ports = st.getSerialPorts()
        devices = []
        for profile in ports:
            device = {
                'deviceName': profile.get('device_name', "Unknown Serial Device"),
                'port': profile.get('port', None),
                'baudrate': profile.get('baudrate', 9600),
                'byteSize': profile.get('bytesize', 8),
                'stopBits': profile.get('stopbits', 1),
                'parity': profile.get('parity', "N"),
            }
            devices.append(device)
        return devices

    def close(self):
        self.com.close()

    def __del__(self):
        if self.com is not None:
            self.com.close()

    @property
    def isOpen(self):
        if self.com is None:
            return None
        return self.com.isOpen()

    @staticmethod
    def _findPossiblePorts():
        return _findPossiblePorts()


if __name__ == "__main__":
    pass
