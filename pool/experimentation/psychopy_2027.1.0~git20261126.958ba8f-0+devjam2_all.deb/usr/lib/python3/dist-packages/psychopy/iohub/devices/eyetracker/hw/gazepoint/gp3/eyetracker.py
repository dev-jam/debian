# -*- coding: utf-8 -*-
# Part of the PsychoPy library
# Copyright (C) 2012-2020 iSolver Software Solutions (C) 2021 Open Science Tools Ltd.
# Distributed under the terms of the GNU General Public License (GPL).

import psychopy.logging as logging

try:
    from psychopy_eyetracker_gazepoint.gazepoint.gp3.eyetracker import (
        ET_UNDEFINED, 
        EyeTracker,
        to_numeric,
        getTime)
except (ModuleNotFoundError, ImportError, NameError):
    logging.error(
        "The Gazepoint eyetracker requires package " 
        "'psychopy-eyetracker-gazepoint' to be installed. Please install this "
        "package and restart the session to enable support.")

# sample event for this device was moved to the plugin, but we're going to use
# the original class for compatibility with older plugin versions
try:
    from psychopy_eyetracker_gazepoint.gazepoint.gp3.eyetracker import (
        GazepointSampleEvent)
except (ModuleNotFoundError, ImportError, NameError):
    # import it from the old iohub location
    from ....eye_events import GazepointSampleEvent


if __name__ == "__main__":
    pass
