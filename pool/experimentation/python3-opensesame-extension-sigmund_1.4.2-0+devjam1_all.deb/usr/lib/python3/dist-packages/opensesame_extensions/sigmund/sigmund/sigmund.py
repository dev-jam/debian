from libopensesame.py3compat import *
from pathlib import Path
from qtpy.QtCore import Qt
from libopensesame.exceptions import UserAborted
from libopensesame.oslogging import oslogger
from libqtopensesame.extensions import BaseExtension
from libqtopensesame.misc.config import cfg
from .sigmund_widget import OpenSesameSigmundWidget
from sigmund_qtwidget.sigmund_dock_widget import SigmundDockWidget
from libqtopensesame.misc.translate import translation_context
try:
    from pyqt_code_editor import settings
except ImportError:
    settings = None
_ = translation_context('sigmund', category='extension')


class Sigmund(BaseExtension):

    def event_startup(self):
        self._state = 'not_listening'
        self._sigmund_widget = None
        self._visible = False
        self._current_exception = None
        if cfg.sigmund_visible:
            self.activate()

    def event_end_experiment(self, ret_val):
        if ret_val is None or isinstance(ret_val, UserAborted):
            self._current_exception = None
            return
        self._current_exception = ret_val
        ret_val._read_more += '''
    
<a id="read-more" class="important-button" href="opensesame://event.sigmund_fix_exception">
Ask Sigmund to fix this
</a>'''

    def event_sigmund_fix_exception(self):
        if self._current_exception is None:
            return
        if self._state != 'connected':
            self.activate()  # Show dock and connect
            self.extension_manager.fire(
                'notify',
                message=_("Connect to Sigmund and try again!"),
                category='info',
                timeout=5000
            )
            return
        if not self._sigmund_widget:
            return
        self._sigmund_widget._current_item_name = self._current_exception.item
        if self._sigmund_widget:
            self._sigmund_widget.send_user_message(str(self._current_exception))
        self.extension_manager.fire(
            'notify',
            message=_("Sigmund is trying to fix your error. Please wait …"),
            category='info',
            timeout=5000,
            always_show=True
        )

    def event_open_item(self, name):
        if not self._sigmund_widget:
            return        
        oslogger.info(f'Sigmund: opening item {name}')
        self._sigmund_widget._current_item_name = name

    def event_open_general_properties(self):
        oslogger.info('Sigmund: opening general properties')
        self.event_open_item(None)

    def event_open_general_script(self):
        oslogger.info('Sigmund: opening general script')
        self.event_open_item(None)

    def event_rename_item(self, from_name, to_name):
        if not self._sigmund_widget:
            return
        if self._sigmund_widget._current_item_name == from_name:
            self._sigmund_widget._current_item_name = to_name

    def activate(self, *dummy):
        """
        Called when the extension is activated. Toggles the dock’s visibility
        and starts the server if needed.
        """
        # Toggle
        if self._visible:
            cfg.sigmund_visible = self._visible = False
            self.set_checked(False)
            if self._sigmund_widget:
                self._dock_widget.hide()
            return
        # Show
        cfg.sigmund_visible = self._visible = True
        self.set_checked(True)
        # Create the dock widget if it doesn't exist
        if self._sigmund_widget is None:
            self._dock_widget = SigmundDockWidget(
                self.main_window, application='OpenSesame',
                sigmund_widget_cls=OpenSesameSigmundWidget)
            self._sigmund_widget = self._dock_widget.sigmund_widget
            self._sigmund_widget.sigmund_extension = self
            if settings:
                font_size = settings.font_size
            else:
                font_size = cfg.pyqode_font_size
            self._sigmund_widget.setStyleSheet(f'font-size: {font_size}pt;')
            self._sigmund_widget.sigmund_extension = self
            self.main_window.addDockWidget(Qt.RightDockWidgetArea,
                                           self._dock_widget)
            self._dock_widget.close_requested.connect(self.activate)
            # Dock widget signals
            self._sigmund_widget.server_state_changed.connect(
                self._on_server_state_changed)
        # Refresh and show
        self._dock_widget.show()

    def refresh_dockwidget_ui(self):
        """Ask the dock widget to update its UI based on the current state."""
        if self._sigmund_widget:
            self._sigmund_widget.refresh_ui()

    def _on_server_state_changed(self, new_state):
        """
        React to the dock widget's server-state changes with OS-specific logic
        (e.g. notifications).
        """
        self._state = new_state
        if new_state == 'failed':
            self.extension_manager.fire(
                'notify',
                message=_("Sigmund server failed to start."),
                category='warning',
                timeout=5000
            )

    def icon(self):
        """Return the icon for the extension."""
        return str(Path(__file__).parent / 'sigmund.png')
    