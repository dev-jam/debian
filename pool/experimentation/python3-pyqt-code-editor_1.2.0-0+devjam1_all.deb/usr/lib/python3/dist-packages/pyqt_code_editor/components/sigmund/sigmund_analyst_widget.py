import os
import subprocess
import time
from sigmund_qtwidget.sigmund_widget import SigmundWidget
from qtpy.QtCore import QEventLoop, QTimer
from qtpy.QtWidgets import QMessageBox, QDialog
from .sigmund_analyst_chat_widget import SigmundAnalystChatWidget
from .confirm_run_code_dialog import ConfirmRunCodeDialog
from ... import settings
import logging
logger = logging.getLogger(__name__)

ACTION_CANCELLED = 'I do not approve this action.'


class SigmundAnalystWidget(SigmundWidget):
    """Extends the default Sigmund widget with Sigmund Analyst-specific
    functionality.
    """
    chat_widget_cls = SigmundAnalystChatWidget
    command_function_prefix = 'ide_'

    def __init__(self, parent, editor_panel):
        super().__init__(parent, application='Sigmund Analyst')
        try:
            self._app = parent.parent()
            self._jupyter_console = self._app._jupyter_console
            # Connect the code_executed signal to a slot
        except AttributeError:
            logger.warning('No Jupyter console found.')
            self._jupyter_console = None
        else:
            self._jupyter_console.execution_complete.connect(
                self._handle_execution_result)
        self._editor_panel = editor_panel
        # Store execution results
        self._execution_result = None
        self._execution_loop = None                

    @property
    def _working_directory(self):
        """The current working directory, based on the most recently active
        editor. Falls back to os.getcwd() if no folder is set.
        """
        folder = settings.current_folder
        return folder if folder is not None else os.getcwd()

    def _resolve_path(self, path):
        """Resolve a path relative to the current working directory.
        Absolute paths are returned unchanged.
        """
        if os.path.isabs(path):
            return path
        return os.path.join(self._working_directory, path)

    def _confirm_action(self, action_type, details):
        """Show a confirmation dialog for the proposed action.

        Args:
            action_type (str): Type of action (e.g., "open file", "execute code")
            details (str): Detailed information about the action

        Returns:
            bool: True if action is approved, False otherwise
        """
        if not settings.sigmund_review_actions:
            return True

        if action_type == "open file":
            return QMessageBox.question(
                self, 
                "Open file",
                f"Sigmund wants to open: \n\n{details}",
                QMessageBox.Ok | QMessageBox.Cancel,
                QMessageBox.Ok
            ) == QMessageBox.Ok
        dialog = ConfirmRunCodeDialog(
            self,
            action_type,
            details
        )
        return dialog.exec_() == QDialog.Accepted

    def _handle_execution_result(self, output, result):
        """Slot that handles the code_executed signal."""
        self._execution_result = output, result
        if self._execution_loop and self._execution_loop.isRunning():
            self._execution_loop.quit()

    def run_command_open_file(self, path):
        path = self._resolve_path(path)
        if settings.sigmund_review_actions:
            if not QMessageBox.question(self, 
                                        "Confirm open file",
                                        f"Sigmund wants to open: \n\n{path}",
                                        QMessageBox.Ok | QMessageBox.Cancel,
                                        QMessageBox.Ok) == QMessageBox.Ok:
                return ACTION_CANCELLED
        self._editor_panel._active_editor = None
        try:
            self._editor_panel.open_file(path)
        except Exception as e:
            return f'Failed to open file: {e}'
        return f'Opened file: {path}'

    def run_command_inspect_files(self, paths, encoding='utf-8'):
        results = []
        for path in paths:
            path = self._resolve_path(path)
            try:
                with open(path, 'r', encoding=encoding) as f:
                    contents = f.read()
                results.append(f'<file path="{path}">\n{contents}\n</file>')
            except FileNotFoundError:
                results.append(f'<file path="{path}" error="File not found" />')
            except Exception as e:
                results.append(f'<file path="{path}" error="{e}" />')
        return '\n\n'.join(results)

    def run_command_list_files(self, path, recursive=False, max_files=250):
        path = self._resolve_path(path)
        lines = []
        try:
            if recursive:
                entries = list(os.walk(path))
            else:
                entries = sorted(os.scandir(path), key=lambda e: e.name)
        except FileNotFoundError:
            return f'Directory not found: {path}'
        except PermissionError:
            return f'Permission denied: {path}'
        except Exception as e:
            return f'Failed to list files: {e}'
        truncated = False
        if recursive:
            for root, dirs, files in entries:
                rel_root = os.path.relpath(root, path)
                prefix = '' if rel_root == '.' else rel_root + os.sep
                for d in sorted(dirs):
                    lines.append(f'{prefix}{d}{os.sep}')
                    if len(lines) >= max_files:
                        truncated = True
                        break
                if truncated:
                    break
                for f in sorted(files):
                    lines.append(f'{prefix}{f}')
                    if len(lines) >= max_files:
                        truncated = True
                        break
                if truncated:
                    break
        else:
            for entry in entries:
                lines.append(entry.name + (os.sep if entry.is_dir() else ''))
                if len(lines) >= max_files:
                    truncated = True
                    break
        if not lines:
            return f'Directory is empty: {path}'
        result = '\n'.join(lines)
        if truncated:
            result += f'\n(truncated at {max_files} entries)'
        return result

    def run_command_execute_code(self, code, language='python'):
        if settings.sigmund_review_actions:
            if not ConfirmRunCodeDialog(self, code, language).exec() \
                    == ConfirmRunCodeDialog.Accepted:
                return ACTION_CANCELLED
        if self._jupyter_console is None:
            return 'Code execution not supported.'
        self._app._toggle_dock_widget(self._jupyter_console, show=True)
        self._jupyter_console.change_directory(self._working_directory)
        time.sleep(.5)
        self._execution_result = None
        self._execution_loop = QEventLoop()
        QTimer.singleShot(5 * 60000, self._execution_loop.quit)  # 5min timeout
        self._jupyter_console.execute_code(code)
        self._execution_loop.exec_()
        self._execution_loop = None
        if self._execution_result is None:
            return 'Code execution timed out or failed to return a result.'
        attachments = []
        for part in self._execution_result[1].get('parts', []):
            for mime_type, data in part.get('data', {}).items():
                print(mime_type)
                if not mime_type.startswith('image/'):
                    continue
                # Generate filename
                ext = mime_type.split('/')[-1]
                filename = f"output_{len(attachments)}.{ext}"            
                attachments.append({
                    "filename": filename,
                    "mime_type": mime_type,
                    "data": data
                })
        if attachments:
            self._attachments = attachments
        else:
            self._attachments = None
        return f'''The following code was executed and generated the output shown below:
<executed_code>
{code}
</executed_code>

<output>
{self._execution_result[0]}
</output>
'''

    def run_command_write_file(self, path, content, encoding='utf-8'):
        path = self._resolve_path(path)
        language = os.path.splitext(path)[1].lstrip('.') or 'text'
        if settings.sigmund_review_actions:
            if not ConfirmRunCodeDialog(self, content, language).exec() \
                    == ConfirmRunCodeDialog.Accepted:
                return ACTION_CANCELLED
        try:
            dir_name = os.path.dirname(path)
            if dir_name:
                os.makedirs(dir_name, exist_ok=True)
            with open(path, 'w', encoding=encoding) as f:
                f.write(content)
        except Exception as e:
            return f'Failed to write file: {e}'
        return f'Wrote file: {path}'

    def run_command_execute_shell_command(self, shell_command, timeout=30,
                                          working_directory=None):
        if settings.sigmund_review_actions:
            if not ConfirmRunCodeDialog(self, shell_command, 'shell').exec() \
                    == ConfirmRunCodeDialog.Accepted:
                return ACTION_CANCELLED
        try:
            result = subprocess.run(
                shell_command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=working_directory if working_directory else self._working_directory
            )
            output = result.stdout
            if result.stderr:
                output += f'\nSTDERR:\n{result.stderr}'
            if not output.strip():
                output = '(no output)'
        except subprocess.TimeoutExpired:
            return f'Shell command timed out after {timeout} seconds.'
        except Exception as e:
            return f'Failed to execute shell command: {e}'
        return f'''The following shell command was executed:
<executed_command>
{shell_command}
</executed_command>

<output>
{output}
</output>
'''

    @property
    def _editor(self):
        return self._editor_panel.active_editor()        

    def send_user_message(self, text, *args, **kwargs):
        current_path = self._editor.code_editor_file_path
        if current_path is None:
            current_path = '[unsaved file]'

        working_directory = self._working_directory

        # Get directory contents with priority to top-level items
        top_level = []
        all_items = []

        try:
            top_level = [f for f in os.listdir(working_directory)
                        if os.path.isfile(os.path.join(working_directory, f))
                        or os.path.isdir(os.path.join(working_directory, f))]

            remaining_slots = max(0, 20 - len(top_level))
            if remaining_slots > 0:
                for root, dirs, files in os.walk(working_directory):
                    if root == working_directory:
                        continue
                    for file in files:
                        if remaining_slots <= 0:
                            break
                        rel_path = os.path.relpath(os.path.join(root, file), working_directory)
                        all_items.append(f".\\{rel_path}")
                        remaining_slots -= 1
                    for dir in dirs:
                        if remaining_slots <= 0:
                            break
                        rel_path = os.path.relpath(os.path.join(root, dir), working_directory)
                        all_items.append(f".\\{rel_path}\\")
                        remaining_slots -= 1

            working_directory_contents = "\n".join(
                sorted([f".\\{item}" if os.path.isfile(os.path.join(working_directory, item))
                 else f".\\{item}\\" for item in top_level] +
                all_items)
            )

            if len(top_level) + len(all_items) > 20:
                working_directory_contents += "\n... (additional files truncated)"

        except PermissionError:
            working_directory_contents = "(Could not read some directory contents - permission denied)"
        except OSError as e:
            working_directory_contents = f"(Could not read directory contents: {str(e)})"

        if settings.sigmund_link_to_workspace:
            system_prompt = f'''## Working directory

IMPORTANT: Do NOT call inspect_files() with {current_path}, because it is already in the workspace.

The workspace corresponds to the following file: {current_path}
The working directory is: {working_directory}

Overview of working directory:

```
{working_directory_contents}
```
'''
        else:
            system_prompt = f'''## Working directory

The working directory is: {working_directory}

Overview of working directory:

```
{working_directory_contents}
```
'''
            
        self._transient_system_prompt = system_prompt
        self._transient_settings = {
            'tool_ide_execute_code': 'true',
            'tool_ide_inspect_files': 'true',
            'tool_ide_list_files': 'true',
            'tool_ide_write_file': 'true',
            'tool_ide_execute_shell_command': 'true'
        }
        # Only if the editor is exposed throught the workspace does it make 
        # sense to activate tools that use the workspace
        if settings.sigmund_link_to_workspace:
            self._transient_settings['tool_ide_open_file'] = 'true'
        else:
            self._transient_settings['tool_update_workspace_content'] = 'false'        
        super().send_user_message(text, *args, **kwargs)
        self._attachments = None
