import re
from qtpy.QtWidgets import QShortcut
from qtpy.QtGui import (
    QSyntaxHighlighter, QTextCharFormat, QColor, QAction,
    QTextCursor, QKeySequence, QTextDocument
)
from qtpy.QtCore import Qt
import logging
from .. import settings
from ..widgets.search_replace_frame import SearchReplaceFrame
logger = logging.getLogger(__name__)


class SearchReplaceHighlighter(QSyntaxHighlighter):
    """
    Syntax highlighter that highlights all matches of a given pattern.
    Updated whenever the pattern or text changes.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self._pattern = ""
        self._use_regex = False
        self._case_sensitive = False
        self._whole_word = False
        self._matches = []  # Stores all matches in the document as (block_number, start, length)

        # Highlight style
        self.highlight_format = QTextCharFormat()
        self.highlight_format.setBackground(QColor(settings.search_replace_background))
        self.highlight_format.setForeground(QColor(settings.search_replace_foreground))

    def setSearchOptions(self, pattern, use_regex, case_sensitive, whole_word):
        self._pattern = pattern
        self._use_regex = use_regex
        self._case_sensitive = case_sensitive
        self._whole_word = whole_word
        self.rehighlight()  # Trigger a re-scan

    def rehighlight(self):
        """Find all matches in the entire document and store them"""
        if not self._pattern or not self.document():
            self._matches = []
            super().rehighlight()
            return

        # Build the pattern
        pattern = self._pattern
        flags = 0 if self._case_sensitive else re.IGNORECASE

        if self._use_regex:
            if self._whole_word:
                pattern = rf"\b{pattern}\b"
            try:
                regex = re.compile(pattern, flags)
            except re.error:
                self._matches = []
                super().rehighlight()
                return
        else:
            pattern = re.escape(pattern)
            if self._whole_word:
                pattern = rf"\b{pattern}\b"
            regex = re.compile(pattern, flags)

        # Find all matches in the entire document
        self._matches = []
        full_text = self.document().toPlainText()

        # Qt uses UTF-16 internally, while Python's re works on Unicode code
        # points. Characters outside the Basic Multilingual Plane (e.g. most
        # emojis, ord > 0xFFFF) are a single Python code point but take up
        # TWO UTF-16 code units (a surrogate pair). This mismatch causes
        # highlight offsets to be wrong whenever such a character appears
        # before a match. We therefore precompute a lookup table that maps
        # each Python string index to its corresponding UTF-16 offset.
        utf16_pos = [0] * (len(full_text) + 1)
        for i, ch in enumerate(full_text):
            utf16_pos[i + 1] = utf16_pos[i] + (2 if ord(ch) > 0xFFFF else 1)

        for match in regex.finditer(full_text):
            utf16_start = utf16_pos[match.start()]
            utf16_end   = utf16_pos[match.end()]

            # Convert UTF-16 positions to block/position
            block = self.document().findBlock(utf16_start)
            block_number = block.blockNumber()
            block_start = block.position()
            block_end = block_start + block.length() - 1

            # Handle matches that span multiple blocks
            while utf16_start <= block_end and utf16_end > block_start:
                match_start_in_block = max(utf16_start - block_start, 0)
                match_end_in_block = min(utf16_end - block_start, block.length() - 1)
                match_length = match_end_in_block - match_start_in_block

                if match_length > 0:
                    self._matches.append((block_number, match_start_in_block, match_length))

                # Move to next block if match spans multiple blocks
                if utf16_end > block_end:
                    block = block.next()
                    if not block.isValid():
                        break
                    block_number = block.blockNumber()
                    block_start = block.position()
                    block_end = block_start + block.length() - 1
                else:
                    break

        super().rehighlight()

    def highlightBlock(self, text):
        """Highlight matches that belong to this block"""
        block_number = self.currentBlock().blockNumber()
        for match_block, start, length in self._matches:
            if match_block == block_number:
                self.setFormat(start, length, self.highlight_format)

class SearchReplace:
    """
    A mixin for QPlainTextEdit that floats a search/replace widget
    at the top-right corner, highlights all matches, and supports
    next/prev/replace operations. Automatically uses a single-line
    selection as the search needle if available.

    This version swaps out your 'original' syntax highlighter with
    our search highlighter while the search widget is visible, so only
    one QSyntaxHighlighter is attached at a time.
    """
    
    def __init__(self, *args, **kwargs):
        """
        The derived editor class must:
          1) Inherit from QPlainTextEdit + SearchReplace
          2) Call super().__init__() properly.
        """
        super().__init__(*args, **kwargs)
        self._originalHighlighter = None  # We'll store your existing syntax highlighter here
        self._searchHighlighter = SearchReplaceHighlighter(None)  # We'll attach/detach dynamically
        
        self.setupSearchReplace()
    
    def setSyntaxHighlighter(self, highlighter):
        """
        Call this to register your normal syntax highlighter.
        We'll attach/detach it as needed.
        """
        self._originalHighlighter = highlighter
        if highlighter:
            highlighter.setDocument(self.document())
    
    def setupSearchReplace(self):
        # Create the search/replace frame
        self._searchFrame = SearchReplaceFrame(self)
        self._searchFrame.setVisible(False)

        # Connect signals
        self._searchFrame.findNextRequested.connect(self.findNext)
        self._searchFrame.findPrevRequested.connect(self.findPrev)
        self._searchFrame.replaceOneRequested.connect(self.replaceOne)
        self._searchFrame.replaceAllRequested.connect(self.replaceAll)

        # Whenever user changes the find text or toggles checkboxes, re-highlight
        self._searchFrame.findEdit.textChanged.connect(self.updateHighlighter)
        self._searchFrame.caseBox.toggled.connect(self.updateHighlighter)
        self._searchFrame.regexBox.toggled.connect(self.updateHighlighter)
        self._searchFrame.wholeWordBox.toggled.connect(self.updateHighlighter)

        # Shortcuts: use platform bindings if available, otherwise fall back
        find_bindings = QKeySequence.keyBindings(QKeySequence.StandardKey.Find)
        if not find_bindings:
            find_bindings = [QKeySequence("Ctrl+F")]

        replace_bindings = QKeySequence.keyBindings(QKeySequence.StandardKey.Replace)
        if not replace_bindings:
            replace_bindings = [QKeySequence("Ctrl+H")]

        findShortcut = QShortcut(find_bindings[0], self)
        findShortcut.setContext(Qt.WidgetWithChildrenShortcut)
        findShortcut.activated.connect(self.showSearchOnly)

        replShortcut = QShortcut(replace_bindings[0], self)
        replShortcut.setContext(Qt.WidgetWithChildrenShortcut)
        replShortcut.activated.connect(self.showSearchReplace)

        # Hide on Escape if wanted
        self.escapeAction = QAction(self)
        self.escapeShortcut = QShortcut(QKeySequence.Cancel, self)
        self.escapeShortcut.setContext(Qt.WidgetWithChildrenShortcut)
        self.escapeShortcut.activated.connect(self.hideSearch)
        self.escapeShortcut.setEnabled(False)
        self.escapeAction.triggered.connect(self.hideSearch)
        self.escapeAction.setEnabled(False)
        self.addAction(self.escapeAction)
        
    def _showSearchReplace(self, search_only):
        # If user has single-line selection, auto-populate
        cursor = self.textCursor()
        if cursor.hasSelection():
            needle = cursor.selectedText().splitlines()            
            if len(needle) == 1:
                needle = needle[0].strip()
                self._searchFrame.findEdit.setText(needle)
            else:
                needle = self._searchFrame.findEdit.text()
            self._updateMatchLabel(needle, self._find_flags())
        
        if search_only:
            self._searchFrame.showSearchOnly()
        else:
            self._searchFrame.showSearchReplace()
        self._searchFrame.setVisible(True)
        self._searchFrame.findEdit.setFocus()
        self._searchFrame.findEdit.selectAll()
        self.updateSearchPosition()
        
        # Swap out original highlighter for the search highlighter
        self._swapToSearchHighlighter()
        self.updateHighlighter()
        self.escapeAction.setEnabled(True)
        self.escapeShortcut.setEnabled(True)         
    
    def showSearchOnly(self):
        self._showSearchReplace(search_only=True)
    
    def showSearchReplace(self):
        self._showSearchReplace(search_only=False)
    
    def hideSearch(self):
        self._searchFrame.setVisible(False)
        self.setFocus()
        self.escapeAction.setEnabled(False)
        self.escapeShortcut.setEnabled(False)
        # Revert to original highlighter
        self._revertToOriginalHighlighter()
    
    def resizeEvent(self, event):
        """ Overridden to keep the search frame pinned top-right. """
        super().resizeEvent(event)
        self.updateSearchPosition()
    
    def updateSearchPosition(self):
        if self._searchFrame.isVisible():
            # Pin to top-right with some margin
            margin = 20
            frame_width = self._searchFrame.width()
            self._searchFrame.move(self.width() - frame_width - margin, margin)
    
    def _swapToSearchHighlighter(self):
        """
        Temporarily remove the original syntax highlighter
        and attach the search highlighter.
        """
        if self._originalHighlighter:
            self._originalHighlighter.setDocument(None)
        self._searchHighlighter.setDocument(self.document())
    
    def _revertToOriginalHighlighter(self):
        """
        Detach the search highlighter and restore the original highlighter.
        """
        self._searchHighlighter.setDocument(None)
        if self._originalHighlighter:
            self._originalHighlighter.setDocument(self.document())
            
    def _find_flags(self, forward=True):
        flags = QTextDocument.FindFlag(0)
        if self._searchFrame.caseBox.isChecked():
            flags |= QTextDocument.FindFlag.FindCaseSensitively
        if not forward:
            flags |= QTextDocument.FindFlag.FindBackward
        if self._searchFrame.wholeWordBox.isChecked():
            flags |= QTextDocument.FindFlag.FindWholeWords
        return flags
    
    def findNext(self):
        self._find(forward=True)
    
    def findPrev(self):
        self._find(forward=False)
    
    def _find(self, forward=True):
        flags = self._find_flags(forward=forward) 
        needle = self._searchFrame.findEdit.text()
        if not needle:
            self._searchFrame.matchCountLabel.clear()
            return
        
        # 1) Attempt to find next/prev match.
        found = self.find(needle, flags)
        
        # 2) If not found, do wrap-around by jumping to start or end.
        if not found:
            cursor = self.textCursor()
            if forward:
                cursor.movePosition(QTextCursor.Start)
            else:
                cursor.movePosition(QTextCursor.End)
            self.setTextCursor(cursor)
            self.find(needle, flags)

        # 3) Regardless of found or wrap-around success, update label:
        self._updateMatchLabel(needle, flags)

    def _updateMatchLabel(self, needle, flags):
        """
        Counts how many total occurrences are in the document
        and which occurrence the cursor is currently on. Then sets
        "X of Y" in self._searchFrame.matchCountLabel, or clears
        it if no matches are found.
        """
        if not needle:
            self._searchFrame.matchCountLabel.clear()
            return
        
        # We'll remove any backward flag to count from top to bottom
        # so we can do a standard forward pass for counting:
        forward_flags = QTextDocument.FindFlag(flags & ~QTextDocument.FindBackward)

        # Save the user's current cursor
        saved_cursor = self.textCursor()

        # Move a fresh cursor to the start
        temp_cursor = QTextCursor(self.document())
        temp_cursor.movePosition(QTextCursor.Start)

        total_matches = 0
        current_index = 0

        # We'll store all match positions so we can see which is "current"
        found_positions = []

        # 1) Find all matches from top to bottom.
        while True:
            temp_cursor = self.document().find(needle, temp_cursor, forward_flags)
            if temp_cursor.isNull():
                break
            found_positions.append((temp_cursor.position(), temp_cursor.anchor()))
            total_matches += 1
        
        if total_matches == 0:
            # No matches at all
            self._searchFrame.matchCountLabel.setText('0 of 0')
            # Restore original cursor
            self.setTextCursor(saved_cursor)
            return
        
        # 2) Determine which match is "current" by comparing
        # our saved_cursor's position to the found positions:
        current_pos = saved_cursor.position()
        current_anchor = saved_cursor.anchor()

        for idx, (pos, anch) in enumerate(found_positions, start=1):
            if pos == current_pos and anch == current_anchor:
                current_index = idx
                break
        
        if current_index == 0:
            # Possibly just in wrap-around scenario; we can do extra logic
            # or default to 1 (the last found match).
            current_index = total_matches

        # 3) Update the label text
        self._searchFrame.matchCountLabel.setText(f"{current_index} of {total_matches}")

        # 4) Restore original cursor
        self.setTextCursor(saved_cursor)
    
    def replaceOne(self):
        needle = self._searchFrame.findEdit.text()
        if not needle:
            return
        
        cursor = self.textCursor()
        if cursor.hasSelection():
            # Optionally verify the selected text is the current match. We'll skip that check here.
            replacement_text = self._searchFrame.replaceEdit.text()
            cursor.insertText(replacement_text)
            self.setTextCursor(cursor)
        self.findNext()
        self.updateHighlighter()
        self.set_modified(True)
    
    def replaceAll(self):
        needle = self._searchFrame.findEdit.text()
        if not needle:
            return

        replacement = self._searchFrame.replaceEdit.text()

        # Save cursor and get current text
        saved_cursor = self.textCursor()
        cursor_pos = saved_cursor.position()
        text = self.toPlainText()

        # Build regex pattern
        flags = 0 if self._searchFrame.caseBox.isChecked() else re.IGNORECASE
        patt = needle
        if not self._searchFrame.regexBox.isChecked():
            patt = re.escape(patt)
        if self._searchFrame.wholeWordBox.isChecked():
            patt = rf"\b{patt}\b"

        try:
            compiled = re.compile(patt, flags)
        except re.error:
            return

        # Get text before cursor
        text_before = text[:cursor_pos]

        # Apply replacement to full text
        try:
            new_text, num_replacements = compiled.subn(replacement, text)
        except re.error as e:
            logging.error(f"Regex error during replacement: {e}")
            return

        # Apply replacement to just the before portion to calculate position change
        new_text_before, _ = compiled.subn(replacement, text_before)
        length_change = len(new_text_before) - len(text_before)
        new_cursor_pos = cursor_pos + length_change

        # Use a single undoable operation
        cursor = self.textCursor()
        cursor.beginEditBlock()
        cursor.select(QTextCursor.Document)
        cursor.insertText(new_text)
        cursor.setPosition(new_cursor_pos)
        cursor.endEditBlock()
        self.setTextCursor(cursor)

        # Update UI
        self._searchFrame.findEdit.setText(replacement)
        self.updateHighlighter()
        self.set_modified(True)
    
    def updateHighlighter(self):
        # When search widget is hidden, the search highlighter won't be attached
        # So only do this if the widget is visible
        if not self._searchFrame.isVisible():
            return
        
        find_text = self._searchFrame.findEdit.text()
        use_regex = self._searchFrame.regexBox.isChecked()
        case_sensitive = self._searchFrame.caseBox.isChecked()
        whole_word = self._searchFrame.wholeWordBox.isChecked()
        
        self._searchHighlighter.setSearchOptions(
            find_text, use_regex, case_sensitive, whole_word
        )
        
        # Count total matches to enable/disable buttons
        match_count = 0
        if find_text:
            flags = 0 if case_sensitive else re.IGNORECASE
            pattern = find_text
            if not use_regex:
                pattern = re.escape(pattern)
            if whole_word:
                pattern = rf"\b{pattern}\b"
            try:
                compiled = re.compile(pattern, flags)
                match_count = len(compiled.findall(self.toPlainText()))
            except re.error:
                match_count = 0
        
        # Enable/disable buttons based on matches
        has_matches = (match_count > 0)
        self._searchFrame.findNextBtn.setEnabled(has_matches)
        self._searchFrame.findPrevBtn.setEnabled(has_matches)
        self._searchFrame.replaceBtn.setEnabled(has_matches)
        self._searchFrame.replaceAllBtn.setEnabled(has_matches)
        self._updateMatchLabel(self._searchFrame.findEdit.text(),
                               self._find_flags())
