"""Fully featured code-editor widgets for PyQt"""

import os
# qtpy prefers PyQt5 when it is installed; this code needs Qt 6.
os.environ.setdefault('QT_API', 'pyqt6')

from ._settings import settings

__version__ = '1.2.0'
