from typing import Final

HIGHLIGHTS_QUERY: Final[str]
INJECTIONS_QUERY: Final[str]
LOCALS_QUERY: Final[str]
TAGS_QUERY: Final[str]

def language() -> object: ...
