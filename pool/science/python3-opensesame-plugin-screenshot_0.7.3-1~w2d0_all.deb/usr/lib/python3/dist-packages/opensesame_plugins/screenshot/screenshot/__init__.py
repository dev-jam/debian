"""Take screenshot of stimulus"""

from .. import __version__

# The category determines the group for the plugin in the item toolbar
category = "Screenshot"
# Defines the GUI controls
controls = [
    {
        "type": "checkbox",
        "var": "verbose",
        "label": "Verbose mode",
        "name": "checkbox_verbose_mode"
    },  {
        "type": "checkbox",
        "var": "window_stim_psycho",
        "label": "Stimulus display (PsychoPy)",
        "name": "checkbox_window_stim_psycho"
    },  {
        "type": "checkbox",
        "var": "window_stim_pil",
        "label": "Stimulus display (PIL)",
        "name": "checkbox_window_stim_pil"
    },  {
        "type": "checkbox",
        "var": "window_full_pil",
        "label": "Composite of all displays (PIL)",
        "name": "checkbox_window_full_pil"
    },  {
        "type": "line_edit",
        "var": "filename_screenshot",
        "label": "Filename",
        "name": "line_edit_filename_screenshot",
        "info": "Filename with extension, extension determines the picture format (.png; .jpg; etc.)"
    }, {
        "type": "text",
        "label": f"<small>Screenshot version {__version__}</small>"
    }
]
