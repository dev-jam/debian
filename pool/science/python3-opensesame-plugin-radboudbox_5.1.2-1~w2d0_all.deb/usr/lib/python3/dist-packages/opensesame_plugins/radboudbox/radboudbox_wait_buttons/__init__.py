"""Radboud Buttonbox - starts button registration on the foreground"""

from .. import __version__

# The category determines the group for the plugin in the item toolbar
category = "RadboudBox"
# Defines the GUI controls
controls = [
    {
        "type": "line_edit",
        "var": "allowed_responses",
        "label": "Allowed responses",
        "name": "line_edit_allowed_responses",
        "info": "e.g. A;B (a-h release, S/V sound/voice)"
    }, {
        "type": "line_edit",
        "var": "correct_response",
        "label": "Correct response",
        "name": "line_edit_correct_response",
        "info": "e.g. A, or A;B"
    }, {
        "type": "line_edit",
        "var": "timeout",
        "label": "Timeout (ms)",
        "name": "line_edit_timeout",
        "info": "In ms, or 'infinite'"
    }, {
        "type": "text",
        "label": "<b>IMPORTANT:</b> this is a foreground item, it will wait for the button press/release or till the timeout has ended before advancing to the next item."
    }, {
        "type": "text",
        "label": "<small><b>Note:</b> Radboudbox init item at the begin of the experiment is needed for initialization of the buttonbox</small>"
    }, {
        "type": "text",
        "label": f"<small>Radboud Buttonbox version {__version__}</small>"
    }
]
